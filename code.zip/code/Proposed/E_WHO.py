import numpy as np
import random,math


def Algm():
    N, M = 10,5 # N -> Total number of hunters
    lb,ub = 0,1
    t=0
    Tmax = 10
    b = random.uniform(-1,1) # parameter
    p = random.uniform(0,2)
    c, r = random.uniform(0,1),random.uniform(0,1)
    pi = 3.14
    Teta = 2*pi*r # wind angle
    phi = Teta+pi

    def initialize(n,m):
        data = []
        for i in range(n):
            tem = []
            for j in range(m):
                tem.append(random.uniform(lb,ub))
            data.append(tem)
        return data
    def Fitness(soln):   #creating function for fitness
        fit = []
        for i in range(len(soln)):
            S = random.random()
            f = 1 / S
            fit.append(f)
        return fit

    Y = initialize(N,M) # Population initialization
    Y_lead = [0]*N # initializing Y_lead (first best solution)
    Y_succ = [0]*N # initializing Y_succ (second best solution)
    overall_best = []
    overall_fit = []
    while t<Tmax:
        Fit = Fitness(Y)  # fitness calculation
        best = np.argmax(Fit)  # minimization problem
        overall_fit.append(max(Fit))
        overall_best.append(Y[best])
        new_Y = []
        for i in range(len(Y)):
            a = (pi/8)*r # Eq.8
            lamda = Teta-a
            X = 1/4*np.log(t+(1/Tmax))*b
            L = 2*c
            v = random.random()
            rand=random.uniform(0,1)

            if p<1:
                if (abs(L)>=1):
                    y = (1/4)*np.log(i+(1/Tmax))
                    Y = (1 / (2 - rand * L)) * (Y_lead[0] * int(1 - X * p * L) + y * lamda * (1 - rand * L) + (
                        X * p * (Y_lead[0]) - (1 - lamda) * Y_lead[0]) * (1 - rand * L) - rand * Y_succ[0] * lamda)
                    new_Y.append([Y])
                else:

                    Y = (np.asarray(Y_lead)).tolist()  # Eq.12
                    new_Y.append(Y)
            else:

                Y = (np.asarray(Y_lead).tolist())  # Eq.11
                new_Y.append(Y)
        Y = new_Y.copy()
        best_1 = (np.argsort(overall_fit)).tolist()
        best = np.argmax(overall_fit)
        Y_lead = overall_best[best]
        best_1.pop(best)
        if len(best_1)<1:
            next_best = best
        else:
            next_best = best_1[0]
        Y_succ = overall_best[next_best]
        t += 1
    best = np.argmax(overall_fit)
    Y_lead = overall_best[best]

    return abs(np.mean(Y_lead))






