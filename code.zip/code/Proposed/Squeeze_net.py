from keras.layers import Input, Conv2D, MaxPool2D, ReLU, concatenate, Dropout, AvgPool2D
from keras.models import Model
from sklearn.model_selection import train_test_split
import warnings
warnings.filterwarnings("ignore")
from Proposed import E_WHO
from keras.src.optimizers import Adam as Opt
import numpy as np


def fire_module(x, s1, e1, e3):
    s1x = Conv2D(s1, kernel_size=1, padding='same')(x)
    s1x = ReLU()(s1x)
    e1x = Conv2D(e1, kernel_size=1, padding='same')(s1x)
    e3x = Conv2D(e3, kernel_size=3, padding='same')(s1x)
    x = concatenate([e1x, e3x])
    x = ReLU()(x)
    return x


def SqueezeNet(input_shape, nclasses):
    input = Input(input_shape)
    x = Conv2D(96, kernel_size=(7, 7), strides=(2, 2), padding='same')(input)
    x = MaxPool2D(pool_size=(3, 3), strides=(2, 2))(x)
    x = fire_module(x, s1=16, e1=64, e3=64)           # 2
    x = fire_module(x, s1=16, e1=64, e3=64)           # 3
    x = fire_module(x, s1=32, e1=128, e3=128)         # 4
    x = MaxPool2D(pool_size=(3, 3), strides=(2, 2))(x)
    x = fire_module(x, s1=32, e1=128, e3=128)         # 5
    x = fire_module(x, s1=48, e1=192, e3=192)         # 6
    x = fire_module(x, s1=48, e1=192, e3=192)         # 7
    x = fire_module(x, s1=64, e1=256, e3=256)         # 8
    x = MaxPool2D(pool_size=(3, 3), strides=(2, 2))(x)
    x = fire_module(x, s1=64, e1=256, e3=256)         # 9
    x = Dropout(0.5)(x)
    x = Conv2D(nclasses, kernel_size=1)(x)
    output = AvgPool2D(pool_size=(13, 13))(x)
    model = Model(input, output)
    return model


def call_method(Feature, Label, tr, Label1):

    x_train, x_test, y_train, y_test = train_test_split(Feature, Label, train_size=tr)

    model = SqueezeNet((256, 256, 3), 3)  # Squeezenet
    value = E_WHO.Algm()
    model.compile(optimizer=Opt(learning_rate=value), loss='binary_crossentropy', metrics=['accuracy'])
    # model.summary()

    x_train = np.resize(x_train, (len(x_train), 256, 256, 3))
    x_test = np.resize(x_test, (len(Feature), 256, 256, 3))
    y_train = np.resize(y_train, (len(x_train), 1, 1, 3))

    epoch = 80
    batch_size = 32
    model.fit(x_train, y_train, epochs=epoch, batch_size=batch_size, verbose=0)
    predict = model.predict(x_test)
    predict = abs(np.round(predict)).astype("int")
    predict1 = predict

    Feature1, Label2 = [], []

    i = 0
    while i < len(Feature):
        if predict1[i] == 1:
            for j in range(5):
                Feature1.append(Feature[i])
                Label2.append(Label1[i])
                i = i+1
        else: i+=5

    Feature1 = np.array(Feature1)
    Label2 = np.array(Label2)
    return Feature1, Label2
