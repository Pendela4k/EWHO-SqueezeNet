import os
from Comparative import E_DH0
from sklearn.model_selection import train_test_split
import numpy as np
from keras.src.optimizers import Adam as Opt
from keras.layers import Conv2D, MaxPooling2D, Flatten, Dense
from keras.models import Sequential
from keras.layers import Flatten, Dense
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'


def call_method(Feature, Label, tr,  ACC, TPR, TNR):

    x_train, x_test, y_train, y_test = train_test_split(Feature, Label, train_size=tr)

    # Define the model
    model = Sequential()
    model.add(Conv2D(32, (3, 3), activation='relu', input_shape=(32, 32, 3)))
    model.add(MaxPooling2D(pool_size=(2, 2)))
    model.add(Conv2D(64, (3, 3), activation='relu'))
    model.add(MaxPooling2D(pool_size=(2, 2)))
    model.add(Flatten())
    model.add(Dense(128, activation='relu'))
    model.add(Dense(1, activation='softmax'))
    value = E_DH0.Algm()
    model.compile(optimizer=Opt(learning_rate=value), loss='categorical_crossentropy', metrics=['accuracy'])

    x_train = np.resize(x_train, (len(x_train), 32, 32, 3))
    x_test = np.resize(x_test, (len(x_test), 32, 32, 3))
    y_train = np.resize(y_train, (len(x_train)))
    model.fit(x_train, y_train, batch_size=32, epochs=10, verbose=0)

    predict = model.predict(x_test)
    pred = abs(np.round(predict)).astype("int")

    tp, tn, fn, fp, a = 0, 0, 0, 0, 2.6
    uni, b = np.unique(y_test), 2.4
    for j in range(len(uni)):
        c = uni[j]
        for i in range(len(pred)):
            if y_test[i] == c and (pred[i]).any() == c:
                tp += 1
            if y_test[i] != c and (pred[i]).any() != c:
                tn += 1
            if y_test[i] == c and (pred[i]).any() != c:
                fn += 1
            if y_test[i] != c and (pred[i]).any() == c:
                fp += 1
    Accuracy = (tp + tn) / (tn + tp + fn + fp)
    Tpr = tp / (tp + fn)
    Tnr = tn / (tn + fp)
    ACC.append(Accuracy)
    TPR.append(Tpr)
    TNR.append(Tnr)

    return ACC, TPR, TNR
