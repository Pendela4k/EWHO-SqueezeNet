# Import necessary libraries
import numpy as np
from sklearn.cross_decomposition import PLSRegression
from sklearn.model_selection import train_test_split
import logging
logging.getLogger('tensorflow').disabled = True
import warnings
warnings.filterwarnings("ignore")


def call_method(Feature, Label, tr,  ACC, TPR, TNR):

    x_train, x_test, y_train, y_test = train_test_split(Feature, Label, train_size=tr)

    n_components = 3
    Model = PLSRegression(n_components=n_components)
    # Fit the model on the training data
    Model.fit(x_train, y_train)
    # Predictions on the test set
    predict = Model.predict(x_test)
    pred = abs(np.round(predict)).astype("int")

    tp, tn, fn, fp, a = 0, 0, 0, 0, 2.6
    uni, b = np.unique(y_test), 2.4
    for j in range(len(uni)):
        c = uni[j]
        for i in range(len(pred)):
            if y_test[i] == c and (pred[i]).any() == c:
                tp += 1
            if y_test[i] != c and (pred[i]).any() != c:
                tn += 1
            if y_test[i] == c and (pred[i]).any() != c:
                fn += 1
            if y_test[i] != c and (pred[i]).any() == c:
                fp += 1
    Accuracy = (tp + tn) / (tn + tp + fn + fp)
    Tpr = tp / (tp + fn)
    Tnr = tn / (tn + fp)
    ACC.append(Accuracy)
    TPR.append(Tpr)
    TNR.append(Tnr)

    return ACC, TPR, TNR




