from keras.layers import Embedding
from keras.models import Model
from keras.layers import Dense
from keras.layers import Flatten, Conv1D, MaxPooling1D, AveragePooling1D, concatenate, Input, Dropout
from sklearn.model_selection import train_test_split
import numpy as np


def model(output_dim=8, max_length=50, y_dim=5, num_filters=5, filter_sizes=[3, 5], pooling='max', pool_padding='valid',
          dropout=0.5):

    embed_input = Input(shape=(max_length,))
    x = Embedding(5, output_dim, input_length=max_length)(embed_input)

    pooled_outputs = []
    for i in range(len(filter_sizes)):
        conv = Conv1D(num_filters, kernel_size=filter_sizes[i], padding='valid', activation='relu')(x)
        if pooling == 'max':
            conv = MaxPooling1D(pool_size=max_length - filter_sizes[i] + 1, strides=1, padding=pool_padding)(conv)
        else:
            conv = AveragePooling1D(pool_size=max_length - filter_sizes[i] + 1, strides=1, padding=pool_padding)(conv)
        pooled_outputs.append(conv)
    merge = concatenate(pooled_outputs)

    x = Flatten()(merge)
    x = Dropout(dropout)(x)
    predictions = Dense(y_dim, activation='softmax')(x)  # TEST

    model = Model(inputs=embed_input, outputs=predictions)

    return model


def call_model(Feature, Label, tr,  ACC, TPR, TNR):

    x_train, x_test, y_train, y_test = train_test_split(Feature, Label, train_size=tr)

    PDCNN = model(output_dim=16, max_length=x_train.shape[1], y_dim=1, filter_sizes=[3, 4, 5], pooling='max', dropout=0.5)

    PDCNN.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['acc'])
    x_train = np.resize(x_train, (len(x_train), x_train.shape[1]))
    x_train[x_train > 4] = 1
    x_test[x_test > 4] = 1
    PDCNN.fit(x_train, y_train, epochs=80, batch_size=32, verbose=0)

    x_test = np.resize(x_test, (len(Feature), x_train.shape[1]))
    predict = PDCNN.predict(x_test)
    pred = abs(np.round(predict)).astype("int")

    tp, tn, fn, fp = 0, 0, 0, 0
    uni= np.unique(y_test)
    for j in range(len(uni)):
        c = uni[j]
        for i in range(len(y_test)):
            if y_test[i] == c and pred[i] == c:
                tp += 1
            if y_test[i] != c and pred[i] != c:
                tn += 1
            if y_test[i] == c and pred[i] != c:
                fn += 1
            if y_test[i] != c and pred[i] == c:
                fp += 1
    Accuracy = (tp + tn) / (tn + tp + fn + fp)
    Tpr = tp / (tp + fn)
    Tnr = tn / (tn + fp)
    ACC.append(Accuracy)
    TPR.append(Tpr)
    TNR.append(Tnr)

    return ACC, TPR, TNR

