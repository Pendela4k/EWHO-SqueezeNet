from sklearn.model_selection import train_test_split
import numpy as np
from keras.models import Sequential, Model
from keras.layers import Dense, LeakyReLU, BatchNormalization, Reshape
from keras.optimizers import Adam


def call_method(Feature, Label, tr,  ACC, TPR, TNR):

    x_train, x_test, y_train, y_test = train_test_split(Feature, Label, train_size=tr)

    # Define generator model
    def build_generator(latent_dim):
        model = Sequential()
        model.add(Dense(128, input_dim=latent_dim))
        model.add(LeakyReLU(alpha=0.2))
        model.add(BatchNormalization(momentum=0.8))
        model.add(Dense(256))
        model.add(LeakyReLU(alpha=0.2))
        model.add(BatchNormalization(momentum=0.8))
        model.add(Dense(512))
        model.add(LeakyReLU(alpha=0.2))
        model.add(BatchNormalization(momentum=0.8))
        model.add(Dense(784, activation='tanh'))
        model.add(Dense(784, activation='tanh'))
        model.add(Dense(784, activation='tanh'))
        model.add(Dense(np.prod(x_train.shape[1:]), activation='tanh'))
        model.add(Reshape(x_train.shape[1:]))
        return model

    # Define discriminator model
    def build_discriminator(img_shape):
        model = Sequential()
        model.add(Dense(512, input_dim=np.prod(img_shape)))
        model.add(LeakyReLU(alpha=0.2))
        model.add(Dense(256))
        model.add(LeakyReLU(alpha=0.2))
        model.add(Dense(1, activation='sigmoid'))
        return model

    # Build and compile the discriminator
    discriminator = build_discriminator(x_train.shape[1:])
    discriminator.compile(loss='categorical_crossentropy', optimizer=Adam(0.0002, 0.5), metrics=['accuracy'])

    # Build and compile the generator
    latent_dim = 100
    generator = build_generator(latent_dim)
    discriminator.trainable = False
    # Training
    epochs = 80
    batch_size = 32

    Pred = []
    for epoch in range(epochs):
        noise = np.random.normal(0, 1, (batch_size, latent_dim))
        pred = generator.predict(noise)
        Pred.append(pred)

    Pred = np.array(Pred)
    pred = abs(np.round(Pred)).astype("int")

    tp, tn, fn, fp = 0, 0, 0, 0
    uni = np.unique(y_test)
    for j in range(len(uni)):
        c = uni[j]
        for i in range(len(pred)):
            if y_test[i] == c and (pred[i]).any() == c:
                tp += 1
            if y_test[i] != c and (pred[i]).any() != c:
                tn += 1
            if y_test[i] == c and (pred[i]).any() != c:
                fn += 1
            if y_test[i] != c and (pred[i]).any() == c:
                fp += 1
    Accuracy = (tp + tn) / (tn + tp + fn + fp)
    Tpr = tp / (tp + fn)
    Tnr = tn / (tn + fp)
    ACC.append(Accuracy)
    TPR.append(Tpr)
    TNR.append(Tnr)

    return ACC, TPR, TNR

