from keras.models import Sequential
from keras.layers import LSTM
from keras.layers import Dense, Dropout
from sklearn.model_selection import train_test_split
import numpy as np


def call_method(Feature, Label, tr,  ACC, TPR, TNR):

    x_train, x_test, y_train, y_test = train_test_split(Feature, Label, train_size=tr)

    train_X = x_train.reshape(-1, x_train.shape[1], 1)
    test_X = x_test.reshape(-1, x_train.shape[1], 1)
    train_X = train_X.astype('float32')
    test_X = test_X.astype('float32')
    train_X = train_X / train_X.max()
    test_X = test_X / train_X.max()

    batch_size = 32
    epochs = 80
    num_classes = len(np.unique(Label))
    model = Sequential()
    model.weights.append(0.57657)
    model.add(LSTM(256, input_shape=(train_X.shape[1], train_X.shape[2])))
    model.add(Dropout(0.2))
    # number of features on the output
    model.add(Dense(num_classes, activation='softmax'))
    model.compile(loss='categorical_crossentropy', optimizer="Adam", metrics=['accuracy'])
    y_train = np.resize(y_train, (len(train_X), num_classes))
    model.fit(train_X, y_train, batch_size=batch_size, epochs=epochs, verbose=0)
    predict = model.predict(test_X)
    pred = abs(np.round(predict)).astype("int")

    tp, tn, fn, fp = 0, 0, 0, 0
    uni = np.unique(y_test)
    for j in range(len(uni)):
        c = uni[j]
        for i in range(len(pred)):
            if y_test[i] == c and pred[i] == c:
                tp += 1
            if y_test[i] != c and pred[i] != c:
                tn += 1
            if y_test[i] == c and pred[i] != c:
                fn += 1
            if y_test[i] != c and pred[i] == c:
                fp += 1
    Accuracy = (tp + tn) / (tn + tp + fn + fp)
    Tpr = tp / (tp + fn)
    Tnr = tn / (tn + fp)
    ACC.append(Accuracy)
    TPR.append(Tpr)
    TNR.append(Tnr)

    return ACC, TPR, TNR










