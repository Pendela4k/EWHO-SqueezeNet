import os
from sklearn.model_selection import train_test_split
import numpy as np
from keras.applications import VGG16
from keras.models import Sequential
from keras.layers import Flatten, Dense
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'


def call_method(Feature, Label, tr,  ACC, TPR, TNR):

    x_train, x_test, y_train, y_test = train_test_split(Feature, Label, train_size=tr)

    # Load pre-trained VGG16 model
    vgg_base = VGG16(weights='imagenet', include_top=False, input_shape=(32, 32, 3))

    # Freeze layers in the pre-trained model
    for layer in vgg_base.layers:
        layer.trainable = False

    # Add custom classifier on top of VGG16
    model = Sequential([
        vgg_base,
        Flatten(),
        Dense(512, activation='relu'),
        Dense(1, activation='softmax')
    ])

    # Compile the model
    model.compile(optimizer="Adam", loss='categorical_crossentropy', metrics=['accuracy'])
    x_train = np.resize(x_train, (len(x_train), 32, 32, 3))
    x_test = np.resize(x_test, (len(x_test), 32, 32, 3))
    y_train = np.resize(y_train, (len(x_train)))
    model.fit(x_train, y_train, batch_size=32, epochs=80, verbose=0)

    predict = model.predict(x_test)
    pred = abs(np.round(predict)).astype("int")

    tp, tn, fn, fp = 0, 0, 0, 0
    uni = np.unique(y_test)
    for j in range(len(uni)):
        c = uni[j]
        for i in range(len(pred)):
            if y_test[i] == c and pred[i] == c:
                tp += 1
            if y_test[i] != c and pred[i] != c:
                tn += 1
            if y_test[i] == c and pred[i] != c:
                fn += 1
            if y_test[i] != c and pred[i] == c:
                fp += 1
    Accuracy = (tp + tn) / (tn + tp + fn + fp)
    Tpr = tp / (tp + fn)
    Tnr = tn / (tn + fp)
    ACC.append(Accuracy)
    TPR.append(Tpr)
    TNR.append(Tnr)

    return ACC, TPR, TNR
