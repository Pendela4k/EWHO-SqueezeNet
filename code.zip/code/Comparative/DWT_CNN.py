from keras.models import Sequential
from keras.layers import Dense, Dropout, Flatten, BatchNormalization, Activation
from keras.layers import Conv1D, MaxPooling1D
from sklearn.model_selection import train_test_split
import os
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'
import logging
logging.getLogger('tensorflow').disabled = True
import warnings
warnings.filterwarnings("ignore")
import numpy as np


def call_method(Feature, Label, tr,  ACC, TPR, TNR):

    x_train, x_test, y_train, y_test = train_test_split(Feature, Label, train_size=tr)
    model = Sequential()
    model.add(Conv1D(filters=32, kernel_size=3, activation='relu', input_shape=(32, 32)))
    model.add(Conv1D(filters=64, kernel_size=3, activation='relu'))
    model.add(Dropout(0.5))
    model.add(MaxPooling1D(pool_size=2))
    model.add(Flatten())
    model.add(Dense(100, activation='relu'))
    model.add(Dense(1, activation='softmax'))
    model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])

    x_train = np.resize(x_train, (len(x_train), 32, 32))
    x_test = np.resize(x_test, (len(x_test), 32, 32))
    model.fit(x_train, y_train, epochs=80, batch_size=32, verbose=0)
    predict = model.predict(x_test)
    pred = abs(np.round(predict)).astype("int")

    tp, tn, fn, fp = 0, 0, 0, 0
    uni = np.unique(y_test)
    for j in range(len(uni)):
        c = uni[j]
        for i in range(len(pred)):
            if y_test[i] == c and pred[i]== c:
                tp += 1
            if y_test[i] != c and pred[i] != c:
                tn += 1
            if y_test[i] == c and pred[i] != c:
                fn += 1
            if y_test[i] != c and pred[i] == c:
                fp += 1
    Accuracy = (tp + tn) / (tn + tp + fn + fp)
    Tpr = tp / (tp + fn)
    Tnr = tn / (tn + fp)
    ACC.append(Accuracy)
    TPR.append(Tpr)
    TNR.append(Tnr)

    return ACC, TPR, TNR

