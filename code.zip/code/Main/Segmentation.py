import cv2, re
import os, glob


def brats_seg():
    from keras_segmentation.models.M_segnet import m_segnet
    new_model = m_segnet(n_classes=2, input_height=240, input_width=240, encoder_level=3)

    # new_model.train(
    #     train_images=".../Brats18/",
    #     train_annotations=".../Mask1",
    #     checkpoints_path="M_segnet1", epochs=10)

    new_model.load_weights('M_segnet1.9')
    path1 = '.../Brats18/'
    path2 = '.../Brats18/'

    listing = os.listdir(path1)

    for file in listing:
        filename = os.path.join(path1, file)
        image = cv2.imread(filename)
        out = new_model.predict_segmentation(inp=image)
        out = out.astype('uint8')
        out1 = out*255

        img_outpath = os.path.join(path2)
        img_out_fullpath = os.path.realpath(img_outpath)
        if not os.path.exists(img_out_fullpath):
            os.makedirs(img_out_fullpath)
        out_filename = os.path.join(img_out_fullpath, file[:-3] + 'png')
        # cv2.imwrite(out_filename, out1)


def figshare_seg():
    from keras_segmentation.models.M_segnet import m_segnet
    new_model = m_segnet(n_classes=2, input_height=512, input_width=512, encoder_level=3)

    # new_model.train(
    #     train_images=".../Figshare/",
    #     train_annotations=".../Mask2",
    #     checkpoints_path="M_segnet2", epochs=5)

    new_model.load_weights('M_segnet2.4')
    path1 = '.../Figshare/'
    path2 = '.../Figshare/'

    listing = os.listdir(path1)

    for file in listing:
        filename = os.path.join(path1, file)
        image = cv2.imread(filename)
        out = new_model.predict_segmentation(inp=image)
        out = out.astype('uint8')
        out1 = out * 255

        img_outpath = os.path.join(path2)
        img_out_fullpath = os.path.realpath(img_outpath)
        if not os.path.exists(img_out_fullpath):
            os.makedirs(img_out_fullpath)
        out_filename = os.path.join(img_out_fullpath, file[:-3] + 'png')
        # cv2.imwrite(out_filename, out1)


def Read_segment(Dataset, P_images):

    if Dataset == "Brats18":
        brats_seg()                              # Segmentation
        S_images = glob.glob(".../Brats18/*")
        S_images.sort(key=lambda f: int(re.sub('\D', '', f)))

    else:
        figshare_seg()
        S_images = glob.glob(".../Figshare/*")
        S_images.sort(key=lambda f: int(re.sub('\D', '', f)))

    return S_images