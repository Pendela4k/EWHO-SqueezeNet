import numpy as np
import cv2, glob, os, re

File_path = glob.glob(".../Brats18/*")
File_path .sort(key=lambda f: int(re.sub('\D', '', f)))
Label = []

for file in File_path:
    path = os.path.join(os.getcwd(), file)
    img = cv2.imread(path)

    thresh, binary_img = cv2.threshold(img, 0, 255, cv2.THRESH_BINARY)
    w_pixels = np.where(binary_img == 255)
    print(len(w_pixels[0]))

    if len(w_pixels[0]) > 0:
        for i in range(5):
            Label.append(1)
    else:
        for i in range(5):
            Label.append(0)
# np.save('Label1.npy', Label)


File_path = glob.glob(".../Figshare/*")
File_path .sort(key=lambda f: int(re.sub('\D', '', f)))
Label = []

for file in File_path:
    path = os.path.join(os.getcwd(), file)
    img = cv2.imread(path)

    thresh, binary_img = cv2.threshold(img, 0, 255, cv2.THRESH_BINARY)
    w_pixels = np.where(binary_img == 255)
    print(len(w_pixels[0]))

    if len(w_pixels[0]) > 5000:
        for i in range(5):
            Label.append(1)
    else:
        for i in range(5):
            Label.append(0)

# np.save('Label2.npy', Label)