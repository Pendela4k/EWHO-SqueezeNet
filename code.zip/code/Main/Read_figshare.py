import os, glob
import mat73
import cv2, re
import numpy as np
import matplotlib.pyplot as plt


# --------------------  Read Input Image -----------------------
input_folder = glob.glob(".../Figshare/*/*")
input_folder.sort(key=lambda f: int(re.sub('\D', '', f)))
Label = []

for fold in input_folder:
    print(fold)
    fil_path = os.path.join(os.getcwd(), fold)
    im = mat73.loadmat(fil_path)

    cjdata = im['cjdata']
    image = np.array(cjdata.get('image')).astype(np.float64)        # In MATLAB: image = cjdata.image
    plt.imshow(image)
    # plt.show()

    label = cjdata.get('label').item()               # Use [0,0] indexing in order to convert lable to scalar
    for i in range(5):
        Label.append(int(label))
    PID = cjdata.get('PID')                          # <HDF5 dataset "PID": shape (6, 1), type "<u2">

    norm = cv2.normalize(image, None, alpha=0, beta=255, norm_type=cv2.NORM_MINMAX, dtype=cv2.CV_32F)

    tumorMask = np.array(cjdata.get('tumorMask'))
    tumormask = tumorMask+[0]
    tumormask1 = tumormask
    f_n = fold.split("\\")
    f_name = f_n[2].split(".")

    # cv2.imwrite("Input_data\Figshare\\" + str(f_name[0]) + ".png", norm)
    # cv2.imwrite("Input_data\Mask2/" + str(f_name[0]) + ".png", tumormask1)
    #
    # np.save("Label2.npy", Label)

