import glob
import cv2, os, re


def brats_filter():
    fil_path = glob.glob(".../Brats18/*")                # Brats Data
    fil_path.sort(key=lambda f: int(re.sub('\D', '', f)))

    for i in fil_path:
        print(i)
        path = os.path.join(os.getcwd(), i)
        img = cv2.imread(path)                               # Input image

        NLM = cv2.fastNlMeansDenoisingColored(img, None, 10, 10, 7, 21)  # NLM filter

        file = i.split("\\")
        f = file[0].split("/")
        name = "Process\\" + f[-1] + "\\" + file[-1]
        # cv2.imwrite(name, NLM)


def figshare_filter():
    fil_path = glob.glob(".../Figshare/*")                # Brats Data
    fil_path.sort(key=lambda f: int(re.sub('\D', '', f)))

    for i in fil_path:
        print(i)
        path = os.path.join(os.getcwd(), i)
        img = cv2.imread(path)                               # Input image

        NLM = cv2.fastNlMeansDenoisingColored(img, None, 10, 10, 7, 21)  # NLM filter

        file = i.split("\\")
        f = file[0].split("/")
        name = "Process\\" + f[-1] + "\\" + file[-1]
        cv2.imwrite(name, NLM)


def Read_process(Dataset):

    if Dataset == "Brats18":
        brats_filter()                              # Pre_processing using NLM filter
        P_images = glob.glob(".../Brats18/*")

    else:
        figshare_filter()                           # Pre_processing using NLM filter
        P_images = glob.glob(".../Figshare/*")

    return P_images
