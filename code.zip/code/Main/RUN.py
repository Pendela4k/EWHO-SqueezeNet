from Main import Pre_processing, ROI, Segmentation
from Main import Aug_Feature
from Proposed import Squeeze_net, Squeeze_net1
from Comparative import DWT_CNN, Deep_RNN, TL, ExpDHO_based_Deep_CNN
from Comparative import PDCNN, PLS, GAN


def call_main(Dataset, tr):

    print("Dataset:  ", Dataset)
    P_images = Pre_processing.Read_process(Dataset)                 # Processed Images

    R_images = ROI.Read_process(Dataset, P_images)                  # ROI extracted images

    S_images = Segmentation.Read_segment(Dataset, R_images)         # Segmented Images

    Feature, Label, label1 = Aug_Feature.Read_Feature(Dataset, S_images)

    ACC, TPR, TNR = [], [], []

    print("\n### Brain Tumor Detection ###")
    Feature1, Label1 = Squeeze_net.call_method(Feature, Label, tr, label1)

    print("\n### Brain Tumor Classification ###")
    Squeeze_net1.call_method(Feature1, Label1, tr,  ACC, TPR, TNR)

    print("\n### Comparative Methods ###")
    PDCNN.call_model(Feature1, Label1, tr,  ACC, TPR, TNR)
    ExpDHO_based_Deep_CNN.call_method(Feature1, Label1, tr,  ACC, TPR, TNR)
    PLS.call_method(Feature1, Label1, tr,  ACC, TPR, TNR)
    Deep_RNN.call_method(Feature1, Label1, tr,  ACC, TPR, TNR)
    DWT_CNN.call_method(Feature1, Label1, tr,  ACC, TPR, TNR)
    TL.call_method(Feature1, Label1, tr,  ACC, TPR, TNR)
    GAN.call_method(Feature1, Label1, tr,  ACC, TPR, TNR)

    return ACC, TPR, TNR

