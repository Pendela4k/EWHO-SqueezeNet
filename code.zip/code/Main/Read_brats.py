import os
import cv2, glob
import numpy as np
from medpy.io import load
import matplotlib.pyplot as plt


File_path = glob.glob("...\Brats18\*\*")
count = 1
Label = []

# Read data
for i in range(len(File_path)):
    print(File_path[i])
    d = os.listdir(os.path.join(os.getcwd(), File_path[i]))

    for j in range(len(d)):
        if d[j][-9:-4].lower() == 'flair':
            filefullpath = os.path.join(os.getcwd(), File_path[i], d[j])

            file = filefullpath.split("\\")
            if file[-3] == "HGG":
                lable = 1
            else: lable = 2
            data, image_header = load(filefullpath)

        if d[j][-7:-4].lower() == 'seg':
            filefullpath = os.path.join(os.getcwd(), File_path[i], d[j])
            GT_data1, image_header2 = load(filefullpath)

    img_d = cv2.normalize(src=data, dst=None, alpha=0, beta=255, norm_type=cv2.NORM_MINMAX, dtype=cv2.CV_8U)
    GT_data = cv2.normalize(src=GT_data1, dst=None, alpha=0, beta=255, norm_type=cv2.NORM_MINMAX, dtype=cv2.CV_8U)
    sz = img_d.shape
    GT_data[GT_data >= 3] = 1

    for k in range(sz[2]):
        slice = img_d[:, :, k]                      # Input image
        gt = GT_data[:, :, k]                       # Ground_truth image
        for m in range(5):
            Label.append(lable)

        # cv2.imwrite("Input_data/Brats18/"+str(k)+str(i)+".png", slice)
        # cv2.imwrite("Input_data/Mask1/" + str(k)+str(i) + ".png", gt)
        # np.save("Label1_c.npy", Label)


