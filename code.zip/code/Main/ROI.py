import os.path
import matplotlib.pyplot as plt
import cv2, glob, re


def ROI(Dataset, P_images):

    for i in range(len(P_images)):
        path = os.path.join(os.getcwd(), P_images[i])
        img = cv2.imread(path)

        if Dataset == "Brats18":
            x, y, h, w = 50, 50, 140, 170
            ROI = img[y:y + h, x:x + w]
            # plt.imshow(ROI)
            # plt.show()

            file = path.split("\\")
            name = "...\\Brats18\\" + file[-1]
            ROI = cv2.resize(ROI, (img.shape[0], img.shape[1]))
            cv2.imwrite(name, ROI)

        else:
            x, y, h, w = 100, 65, 380, 350
            ROI = img[y:y + h, x:x + w]

            file = path.split("\\")
            name = "...\\Figshare\\" + file[-1]
            ROI = cv2.resize(ROI, (img.shape[0], img.shape[1]))
            cv2.imwrite(name, ROI)


def Read_process(Dataset, P_images):

    if Dataset == "Brats18":
        ROI(Dataset, P_images)
        R_images = glob.glob(".../Brats18/*")

    else:
        ROI(Dataset, P_images)
        R_images = glob.glob(".../Figshare/*")

    return R_images