import cv2
import numpy as np


def get_pixel_lvp(img, center, x, y):
    new_value = 0
    try:
        if img[x][y] >= center:
            new_value = 1
    except:
        pass
    return new_value


def local_vector_patterns(img, x, y):
    center = img[x][y]
    val_ar = []
    val_ar.append(get_pixel_lvp(img, center, x - 1, y + 1))  # top_right
    val_ar.append(get_pixel_lvp(img, center, x, y + 1))  # right
    val_ar.append(get_pixel_lvp(img, center, x + 1, y + 1))  # bottom_right
    val_ar.append(get_pixel_lvp(img, center, x + 1, y))  # bottom
    val_ar.append(get_pixel_lvp(img, center, x + 1, y - 1))  # bottom_left
    val_ar.append(get_pixel_lvp(img, center, x, y - 1))  # left
    val_ar.append(get_pixel_lvp(img, center, x - 1, y - 1))  # top_left
    val_ar.append(get_pixel_lvp(img, center, x - 1, y))  # top

    power_val = [1, 2, 4, 8, 16, 32, 64, 128]
    P = len(power_val)                                          ## number of neighbours
    val_V_rp = 0
    val_lbp = 0
    for i in range(len(val_ar)):
        val_V_rp += (val_ar[i] * power_val[i]) ** 2             # phi (Ip,Ic,P)^2
        val_lbp += (val_ar[i] * power_val[i])
    feat = (P * val_lbp - val_lbp ** 2) / P ** 2
    return feat


def lv_feat(img):
    gray_image = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    height, width = gray_image.shape
    img_lvp = np.zeros((height, width, 3), np.uint8)
    for k in range(0, height):
        for l in range(0, width):
            img_lvp[k, l] = local_vector_patterns(gray_image, k, l)
    hist_lvp = cv2.calcHist([img_lvp], [0], None, [50], [0, 50])

    return hist_lvp
