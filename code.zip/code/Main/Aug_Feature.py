import glob, os, cv2
import numpy as np
import matplotlib.pyplot as plt
from keras.models import Model
from keras.applications.vgg19 import VGG19 as CNN
from Main import lvp, CLBP


base_model = CNN(weights='imagenet')
model = Model(inputs=base_model.input, outputs=base_model.get_layer('block4_pool').output)

# -------- CNN Features --------
def CNN_based(images):
    x = images
    x = np.expand_dims(x, axis=0)                           # expand the dimension
    x = np.resize(x, (1, 224, 224, 3))                      # resize the image to required format
    block4_pool_features = model.predict(x)                 # size(1, 14, 14, 512)
    mean_block_feat = block4_pool_features.mean(1)          # (1, 14, 512)
    feature_vec = mean_block_feat.mean(1)                   # (1, 512)
    feature_vec = feature_vec[0].tolist()
    return feature_vec[:50]


def color_augmentation(image, brightness_factor, contrast_factor, saturation_factor, hue_factor):
  # Convert the image to HSV colorspace.
  image = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)

  # Change the brightness.
  brightness = image[:, :, 2]
  brightness = brightness * brightness_factor
  brightness = np.clip(brightness, 0, 255)
  image[:, :, 2] = brightness

  # Change the contrast.
  contrast = image[:, :, 1]
  contrast = contrast * contrast_factor
  contrast = np.clip(contrast, 0, 255)
  image[:, :, 1] = contrast

  # Change the saturation.
  saturation = image[:, :, 0]
  saturation = saturation * saturation_factor
  saturation = np.clip(saturation, 0, 255)
  image[:, :, 0] = saturation

  # Change the hue.
  hue = image[:, :, 0]
  hue = hue + hue_factor
  hue = np.clip(hue, 0, 255)
  image[:, :, 0] = hue

  # Convert the image back to RGB colorspace.
  image = cv2.cvtColor(image, cv2.COLOR_HSV2BGR)

  return image


def Feature_extract(S_images):
    Feature = []

    for i in range(len(S_images)):
        path = os.path.join(os.getcwd(), S_images[i])
        img = cv2.imread(path)

        # -------------- Augmentation --------------

        # crop
        x, y, h, w = 60, 65, 300, 300
        crop_img = img[y:y + h, x:x + w]

        # flip the image
        flip = cv2.flip(img, 0)

        # scaling
        ss = cv2.resize(img, (100, 100))

        # color augmentation
        ca = color_augmentation(img, 0.5, 0.1, 0.1, 1)

        # rotate
        rotate = cv2.rotate(img, cv2.ROTATE_180)

        Aug = [crop_img, flip, ss, ca, rotate]

        # -------------- Feature Extraction --------------

        for i in range(len(Aug)):
            data = Aug[i]

            # CNN Feature
            Cnn = CNN_based(data)

            # CLBP
            clbp = CLBP.clbp_main(img).flatten()

            # LVP
            Lvp = lvp.lv_feat(data).flatten()

            Feat = np.concatenate((Cnn, clbp, Lvp))
            Feature.append(Feat)
            np.save("Feature1.npy", Feature)


def Feature_extract1(S_images):
    Feature = []

    for i in range(len(S_images)):
        path = os.path.join(os.getcwd(), S_images[i])
        img = cv2.imread(path)

        # -------------- Augmentation --------------

        # crop
        x, y, h, w = 60, 65, 300, 300
        crop_img = img[y:y + h, x:x + w]

        # flip the image
        flip = cv2.flip(img, 0)

        # scaling
        ss = cv2.resize(img, (100, 100))

        # color augmentation
        ca = color_augmentation(img, 0.5, 0.1, 0.1, 1)

        # rotate
        rotate = cv2.rotate(img, cv2.ROTATE_180)

        Aug = [crop_img, flip, ss, ca, rotate]

        # -------------- Feature Extraction --------------

        for i in range(len(Aug)):
            data = Aug[i]

            # CNN Feature
            Cnn = CNN_based(data)

            # CLBP
            clbp = CLBP.clbp_main(img).flatten()

            # LVP
            Lvp = lvp.lv_feat(data).flatten()

            Feat = np.concatenate((Cnn, clbp, Lvp))
            Feature.append(Feat)
            np.save("Feature2.npy", Feature)


def Read_Feature(Dataset, S_images):

    if Dataset == "Brats18":
        Feature_extract(S_images)
        print("\n### Read Feature Extracted Data ###")
        Feature = np.load("Feature1.npy")
        Label = np.load("Label1.npy")
        Label1 = np.load("Label1_c.npy")
    else:
        Feature_extract1(S_images)
        print("\n### Read Feature Extracted Data ###")
        Feature = np.load("Feature2.npy")
        Label = np.load("Label2.npy")
        Label1 = np.load("Label2_c.npy")

    return Feature, Label, Label1
