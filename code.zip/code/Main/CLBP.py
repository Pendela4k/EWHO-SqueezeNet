import numpy as np, cv2
import random
from matplotlib import pyplot as plt


def get_pixel(img, center, x, y):
    new_value = 0
    try:
        if img[x][y] >= center:
            new_value = 1
    except:
        pass
    return new_value


def model_predict(data):
    data = [random.randrange(0, 2, 1) for i in range(len(data))]
    return data


def flbp_calculated_pixel(img, x, y):
    center = img[x][y]
    val_ar = []
    val_ar.append(get_pixel(img, center, x-1, y+1))     # top_right
    val_ar.append(get_pixel(img, center, x, y+1))       # right
    val_ar.append(get_pixel(img, center, x+1, y+1))     # bottom_right
    val_ar.append(get_pixel(img, center, x+1, y))       # bottom
    val_ar.append(get_pixel(img, center, x+1, y-1))     # bottom_left
    val_ar.append(get_pixel(img, center, x, y-1))       # left
    val_ar.append(get_pixel(img, center, x-1, y-1))     # top_left
    val_ar.append(get_pixel(img, center, x-1, y))       # top
    
    power_val = [1, 2, 4, 8, 16, 32, 64, 128]
    val = 0
    for i in range(len(val_ar)):
        val += val_ar[i] * power_val[i]
    return val


def clbp_main(image):
    height, width = image.shape[0], image.shape[1]
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    img_clbp = np.zeros((height, width, 3), np.uint8)
    for i in range(0, height):
        for j in range(0, width):
             img_clbp[i, j] = flbp_calculated_pixel(gray, i, j)
    plt.imshow(np.bitwise_not(img_clbp))
    # plt.show()
    img_clbp = cv2.calcHist([img_clbp], [0], None, [50], [0, 50])
    return img_clbp

